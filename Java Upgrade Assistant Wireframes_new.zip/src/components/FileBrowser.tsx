import { useState } from 'react';
import { Coffee, ArrowLeft, Folder, File, ChevronRight, ChevronDown, FileCode, Check, PackageSearch, GitBranch } from 'lucide-react';

interface FileBrowserProps {
  repositoryUrl: string;
  analysisType: 'internal' | 'external';
  onAnalyze: (selectedFiles: string[]) => void;
  onBack: () => void;
}

interface FileNode {
  name: string;
  type: 'file' | 'folder';
  path: string;
  children?: FileNode[];
  expanded?: boolean;
}

export function FileBrowser({ repositoryUrl, analysisType, onAnalyze, onBack }: FileBrowserProps) {
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['/', '/src', '/src/main']));
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set(['/pom.xml']));
  const [targetJavaVersion, setTargetJavaVersion] = useState('17');

  // Mock file structure
  const fileStructure: FileNode[] = [
    {
      name: 'src',
      type: 'folder',
      path: '/src',
      children: [
        {
          name: 'main',
          type: 'folder',
          path: '/src/main',
          children: [
            {
              name: 'java',
              type: 'folder',
              path: '/src/main/java',
              children: [
                {
                  name: 'com',
                  type: 'folder',
                  path: '/src/main/java/com',
                  children: [
                    { name: 'example', type: 'folder', path: '/src/main/java/com/example', children: [] }
                  ]
                }
              ]
            },
            {
              name: 'resources',
              type: 'folder',
              path: '/src/main/resources',
              children: [
                { name: 'application.properties', type: 'file', path: '/src/main/resources/application.properties' },
                { name: 'logback.xml', type: 'file', path: '/src/main/resources/logback.xml' }
              ]
            }
          ]
        },
        {
          name: 'test',
          type: 'folder',
          path: '/src/test',
          children: [
            { name: 'java', type: 'folder', path: '/src/test/java', children: [] }
          ]
        }
      ]
    },
    { name: 'pom.xml', type: 'file', path: '/pom.xml' },
    { name: 'build.gradle', type: 'file', path: '/build.gradle' },
    { name: 'README.md', type: 'file', path: '/README.md' },
    { name: '.gitignore', type: 'file', path: '/.gitignore' }
  ];

  const toggleFolder = (path: string) => {
    const newExpanded = new Set(expandedFolders);
    if (newExpanded.has(path)) {
      newExpanded.delete(path);
    } else {
      newExpanded.add(path);
    }
    setExpandedFolders(newExpanded);
  };

  const toggleFileSelection = (path: string) => {
    const newSelected = new Set(selectedFiles);
    if (newSelected.has(path)) {
      newSelected.delete(path);
    } else {
      newSelected.add(path);
    }
    setSelectedFiles(newSelected);
  };

  const renderFileTree = (nodes: FileNode[], depth = 0): JSX.Element[] => {
    return nodes.map((node) => {
      const isExpanded = expandedFolders.has(node.path);
      const isSelected = selectedFiles.has(node.path);

      return (
        <div key={node.path}>
          <div
            className={`flex items-center gap-2 px-3 py-2 hover:bg-gray-100 cursor-pointer rounded ${
              isSelected ? 'bg-orange-50 border border-orange-200' : ''
            }`}
            style={{ paddingLeft: `${depth * 20 + 12}px` }}
            onClick={() => node.type === 'folder' ? toggleFolder(node.path) : toggleFileSelection(node.path)}
          >
            {node.type === 'folder' ? (
              <>
                {isExpanded ? (
                  <ChevronDown className="w-4 h-4 text-gray-500" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-gray-500" />
                )}
                <Folder className="w-4 h-4 text-blue-500" />
              </>
            ) : (
              <>
                <div className="w-4 h-4 flex items-center justify-center">
                  {isSelected && <Check className="w-3 h-3 text-orange-600" />}
                </div>
                {node.name.endsWith('.xml') || node.name.endsWith('.gradle') ? (
                  <FileCode className="w-4 h-4 text-green-500" />
                ) : (
                  <File className="w-4 h-4 text-gray-400" />
                )}
              </>
            )}
            <span className={`text-sm ${isSelected ? 'text-orange-900' : 'text-gray-700'}`}>
              {node.name}
            </span>
            {node.type === 'file' && (node.name.endsWith('.xml') || node.name.endsWith('.gradle')) && (
              <span className="ml-auto text-xs text-gray-500">dependency file</span>
            )}
          </div>
          {node.type === 'folder' && isExpanded && node.children && (
            <div>{renderFileTree(node.children, depth + 1)}</div>
          )}
        </div>
      );
    });
  };

  const handleAnalyze = () => {
    onAnalyze(Array.from(selectedFiles));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Coffee className="w-8 h-8 text-orange-600" />
              <div>
                <h1 className="text-gray-900">Java Upgrade Assistant</h1>
                <p className="text-sm text-gray-500">Streamline your Java migration</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <button className="text-gray-700 hover:text-gray-900">Dashboard</button>
              <button className="text-gray-700 hover:text-gray-900">Assessments</button>
              <button className="text-gray-700 hover:text-gray-900">Reports</button>
              <button className="text-gray-700 hover:text-gray-900">Settings</button>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-white">
                JD
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Back Button */}
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>

        {/* Page Header */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-3">
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
              analysisType === 'internal' ? 'bg-orange-100' : 'bg-blue-100'
            }`}>
              {analysisType === 'internal' ? (
                <GitBranch className="w-6 h-6 text-orange-600" />
              ) : (
                <PackageSearch className="w-6 h-6 text-blue-600" />
              )}
            </div>
            <div>
              <h2 className="text-gray-900">
                {analysisType === 'internal' ? 'Analyze Internal Dependencies' : 'Scan External Libraries'}
              </h2>
              <p className="text-sm text-gray-600">{repositoryUrl}</p>
            </div>
          </div>
        </div>

        {/* Success Banner */}
        <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h4 className="text-green-900 mb-1">Repository Cloned Successfully</h4>
              <p className="text-sm text-green-700">
                Browse the project structure below and select the files you want to analyze
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* File Browser */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-gray-900">Project Files</h3>
                <p className="text-sm text-gray-600 mt-1">
                  {analysisType === 'internal' 
                    ? 'Select source files and dependency configurations to analyze'
                    : 'Select pom.xml or build.gradle to scan external libraries'}
                </p>
              </div>
              <div className="p-4 max-h-[600px] overflow-y-auto">
                {renderFileTree(fileStructure)}
              </div>
            </div>
          </div>

          {/* Configuration Panel */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
              <h3 className="text-gray-900 mb-4">Analysis Configuration</h3>
              
              <div className="mb-6">
                <label className="block text-sm text-gray-700 mb-2">
                  Target Java Version
                </label>
                <select
                  value={targetJavaVersion}
                  onChange={(e) => setTargetJavaVersion(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                >
                  <option value="11">Java 11</option>
                  <option value="17">Java 17 (LTS)</option>
                  <option value="21">Java 21 (LTS)</option>
                  <option value="23">Java 23</option>
                </select>
              </div>

              <div className="mb-6">
                <label className="block text-sm text-gray-700 mb-3">
                  Selected Files
                </label>
                {selectedFiles.size === 0 ? (
                  <p className="text-sm text-gray-500 italic">No files selected</p>
                ) : (
                  <div className="space-y-2">
                    {Array.from(selectedFiles).map((file) => (
                      <div key={file} className="flex items-center gap-2 text-sm">
                        <Check className="w-3 h-3 text-green-600" />
                        <span className="text-gray-700 truncate">{file}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="mb-6">
                <label className="block text-sm text-gray-700 mb-3">
                  Options
                </label>
                <div className="space-y-3">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" defaultChecked className="w-4 h-4 text-orange-600 rounded" />
                    <span className="text-sm text-gray-700">Include test dependencies</span>
                  </label>
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" defaultChecked className="w-4 h-4 text-orange-600 rounded" />
                    <span className="text-sm text-gray-700">Deep scan</span>
                  </label>
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 text-orange-600 rounded" />
                    <span className="text-sm text-gray-700">Check for vulnerabilities</span>
                  </label>
                </div>
              </div>

              <button
                onClick={handleAnalyze}
                disabled={selectedFiles.size === 0}
                className={`w-full px-6 py-3 rounded-lg transition-colors ${
                  selectedFiles.size === 0
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : analysisType === 'internal'
                    ? 'bg-orange-600 text-white hover:bg-orange-700'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                Start Analysis
              </button>
            </div>

            {/* Help Panel */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="text-sm text-blue-900 mb-2">Tips</h4>
              <ul className="text-xs text-blue-700 space-y-1">
                <li>• Click folders to expand/collapse</li>
                <li>• Click files to select/deselect</li>
                <li>• Look for pom.xml or build.gradle</li>
                <li>• Multiple files can be selected</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
