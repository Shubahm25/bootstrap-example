import { useState } from 'react';
import { Coffee, ArrowLeft, PackageSearch, AlertCircle, Info, X } from 'lucide-react';

interface ExternalLibrariesInputProps {
  onCloneRepository: (url: string) => void;
  onBack: () => void;
  error?: string | null;
}

export function ExternalLibrariesInput({ onCloneRepository, onBack, error }: ExternalLibrariesInputProps) {
  const [url, setUrl] = useState('');
  const [showEmptyState, setShowEmptyState] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) {
      setShowEmptyState(true);
      return;
    }
    setShowEmptyState(false);
    onCloneRepository(url);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Coffee className="w-8 h-8 text-orange-600" />
              <div>
                <h1 className="text-gray-900">Java Upgrade Assistant</h1>
                <p className="text-sm text-gray-500">Streamline your Java migration</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <button className="text-gray-700 hover:text-gray-900">Dashboard</button>
              <button className="text-gray-700 hover:text-gray-900">Assessments</button>
              <button className="text-gray-700 hover:text-gray-900">Reports</button>
              <button className="text-gray-700 hover:text-gray-900">Settings</button>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-white">
                JD
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Back Button */}
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </button>

        {/* Page Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center">
              <PackageSearch className="w-6 h-6 text-blue-600" />
            </div>
            <h2 className="text-gray-900">Scan External Libraries</h2>
          </div>
          <p className="text-gray-600">
            Upload your dependency configuration files to identify third-party library compatibility with target Java version
          </p>
        </div>

        {/* Error State */}
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h4 className="text-red-900 mb-1">Analysis Failed</h4>
                <p className="text-sm text-red-700">{error}</p>
              </div>
              <button className="text-red-600 hover:text-red-800">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* Info Banner */}
        <div className="mb-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h4 className="text-blue-900 mb-1">What we&apos;ll analyze</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Third-party library versions and Java compatibility</li>
                <li>• Known vulnerabilities and security issues</li>
                <li>• Available updates for target Java version</li>
                <li>• Breaking changes and migration paths</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Input Form */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <label htmlFor="bitbucket-url" className="block text-gray-900 mb-2">
                Bitbucket Repository URL
              </label>
              <input
                id="bitbucket-url"
                type="text"
                value={url}
                onChange={(e) => {
                  setUrl(e.target.value);
                  setShowEmptyState(false);
                }}
                placeholder="https://bitbucket.org/your-org/your-repo"
                className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  showEmptyState ? 'border-red-300 bg-red-50' : 'border-gray-300'
                }`}
              />
              {showEmptyState && (
                <p className="text-sm text-red-600 mt-2">Please enter a valid repository URL</p>
              )}
              <p className="text-sm text-gray-500 mt-2">
                Enter the full URL of your Bitbucket repository
              </p>
            </div>

            <div className="mb-6">
              <label className="block text-gray-900 mb-2">
                Analysis Options
              </label>
              <div className="space-y-3">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" defaultChecked className="w-4 h-4 text-blue-600 rounded" />
                  <span className="text-gray-700">Check for security vulnerabilities</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" defaultChecked className="w-4 h-4 text-blue-600 rounded" />
                  <span className="text-gray-700">Identify available updates</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" className="w-4 h-4 text-blue-600 rounded" />
                  <span className="text-gray-700">Include transitive dependencies</span>
                </label>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <button
                type="submit"
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Clone Repository
              </button>
              <button
                type="button"
                onClick={onBack}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>

        {/* Empty State Example */}
        <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200 p-12">
          <div className="text-center max-w-md mx-auto">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <PackageSearch className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-gray-900 mb-2">No Scan Started Yet</h3>
            <p className="text-gray-600 mb-6">
              Enter your repository URL above and click Clone Repository to browse and select files for scanning
            </p>
            <div className="inline-flex items-center gap-2 text-sm text-gray-500">
              <Info className="w-4 h-4" />
              <span>Typical scan takes 1-3 minutes</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}