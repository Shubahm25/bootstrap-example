import { useState, useRef } from 'react';
import { Coffee, ArrowLeft, Download, ZoomIn, ZoomOut, Maximize2, Minimize2, AlertCircle, AlertTriangle, CheckCircle2, ChevronRight, ChevronDown } from 'lucide-react';

interface DependencyTreeProps {
  data: any;
  onNavigate: (screen: 'dashboard' | 'input' | 'loading' | 'results' | 'tree' | 'error') => void;
}

interface TreeNode {
  id: string;
  name: string;
  severity: 'critical' | 'warning' | 'compatible';
  children?: TreeNode[];
  expanded?: boolean;
}

export function DependencyTree({ data, onNavigate }: DependencyTreeProps) {
  const [zoom, setZoom] = useState(100);
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set(['root', 'payment', 'user', 'reporting', 'notification']));
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Mock tree data structure
  const treeData: TreeNode = {
    id: 'root',
    name: 'com.example.application',
    severity: 'warning',
    children: [
      {
        id: 'payment',
        name: 'com.example.payment.processor',
        severity: 'critical',
        children: [
          {
            id: 'payment-core',
            name: 'com.example.core.utils',
            severity: 'critical',
            children: [
              {
                id: 'base64',
                name: 'sun.misc.BASE64Encoder',
                severity: 'critical',
              }
            ]
          },
          {
            id: 'payment-validation',
            name: 'com.example.validation',
            severity: 'compatible',
          }
        ]
      },
      {
        id: 'user',
        name: 'com.example.user.authentication',
        severity: 'warning',
        children: [
          {
            id: 'security',
            name: 'com.example.security.jwt',
            severity: 'warning',
          },
          {
            id: 'user-db',
            name: 'com.example.database.connector',
            severity: 'compatible',
          }
        ]
      },
      {
        id: 'reporting',
        name: 'com.example.reporting.engine',
        severity: 'compatible',
        children: [
          {
            id: 'data-export',
            name: 'com.example.data.export',
            severity: 'compatible',
          },
          {
            id: 'template',
            name: 'com.example.template.engine',
            severity: 'compatible',
          }
        ]
      },
      {
        id: 'notification',
        name: 'com.example.notification.service',
        severity: 'critical',
        children: [
          {
            id: 'messaging',
            name: 'com.example.messaging.queue',
            severity: 'critical',
          }
        ]
      }
    ]
  };

  const toggleNode = (nodeId: string) => {
    const newExpanded = new Set(expandedNodes);
    if (newExpanded.has(nodeId)) {
      newExpanded.delete(nodeId);
    } else {
      newExpanded.add(nodeId);
    }
    setExpandedNodes(newExpanded);
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case 'compatible':
        return <CheckCircle2 className="w-4 h-4 text-green-600" />;
      default:
        return null;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'border-red-400 bg-red-50 hover:bg-red-100';
      case 'warning':
        return 'border-yellow-400 bg-yellow-50 hover:bg-yellow-100';
      case 'compatible':
        return 'border-green-400 bg-green-50 hover:bg-green-100';
      default:
        return 'border-gray-300 bg-white';
    }
  };

  const renderTreeNode = (node: TreeNode, isLast: boolean = false, prefix: string = '', isRoot: boolean = false) => {
    const isExpanded = expandedNodes.has(node.id);
    const hasChildren = node.children && node.children.length > 0;

    return (
      <div key={node.id} className="relative">
        {/* Tree Lines */}
        {!isRoot && (
          <div className="absolute left-0 top-0 bottom-0 flex items-start" style={{ width: '40px' }}>
            {/* Horizontal line */}
            <div className="absolute left-0 top-6 w-10 h-px bg-gray-300"></div>
            {/* Vertical line */}
            {!isLast && (
              <div className="absolute left-0 top-0 w-px bg-gray-300" style={{ height: '100%' }}></div>
            )}
          </div>
        )}

        {/* Node Content */}
        <div className={`flex items-start gap-3 ${!isRoot ? 'ml-12' : ''}`}>
          <div className="flex-shrink-0 mt-3">
            {hasChildren && (
              <button
                onClick={() => toggleNode(node.id)}
                className="w-6 h-6 flex items-center justify-center rounded border border-gray-300 bg-white hover:bg-gray-50 transition-colors"
              >
                {isExpanded ? (
                  <ChevronDown className="w-4 h-4 text-gray-600" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-gray-600" />
                )}
              </button>
            )}
          </div>

          <div 
            className={`flex-1 mb-6 inline-flex items-center gap-3 px-4 py-3 border-2 rounded-lg shadow-sm cursor-pointer transition-all ${getSeverityColor(node.severity)}`}
            onClick={() => hasChildren && toggleNode(node.id)}
          >
            {getSeverityIcon(node.severity)}
            <span className="text-gray-900">{node.name}</span>
          </div>
        </div>

        {/* Children */}
        {hasChildren && isExpanded && (
          <div className="relative">
            <div className="ml-12">
              {node.children!.map((child, index) => (
                <div key={child.id} className="relative">
                  {renderTreeNode(child, index === node.children!.length - 1, prefix + (isLast ? '  ' : '│ '))}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className={`min-h-screen bg-gray-50 ${isFullscreen ? 'fixed inset-0 z-50 overflow-auto' : ''}`}>
      {/* Top Navigation */}
      {!isFullscreen && (
        <nav className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Coffee className="w-8 h-8 text-orange-600" />
                <div>
                  <h1 className="text-gray-900">Java Upgrade Assistant</h1>
                  <p className="text-sm text-gray-500">Streamline your Java migration</p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <button className="text-gray-700 hover:text-gray-900">Dashboard</button>
                <button className="text-gray-700 hover:text-gray-900">Assessments</button>
                <button className="text-gray-700 hover:text-gray-900">Reports</button>
                <button className="text-gray-700 hover:text-gray-900">Settings</button>
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-white">
                  JD
                </div>
              </div>
            </div>
          </div>
        </nav>
      )}

      {/* Main Content */}
      <div className={`${isFullscreen ? 'h-screen p-6' : 'max-w-7xl mx-auto px-6 py-8'}`}>
        {/* Back Button */}
        {!isFullscreen && (
          <button 
            onClick={() => onNavigate('results')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Results Table
          </button>
        )}

        {/* Page Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-gray-900 mb-2">Dependency Tree Visualization</h2>
            <p className="text-gray-600">Interactive view of internal dependency relationships</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-white border border-gray-300 rounded-lg p-1">
              <button 
                onClick={() => setZoom(Math.max(50, zoom - 10))}
                className="p-2 hover:bg-gray-100 rounded"
              >
                <ZoomOut className="w-4 h-4 text-gray-600" />
              </button>
              <span className="text-sm text-gray-700 px-2 min-w-[60px] text-center">{zoom}%</span>
              <button 
                onClick={() => setZoom(Math.min(200, zoom + 10))}
                className="p-2 hover:bg-gray-100 rounded"
              >
                <ZoomIn className="w-4 h-4 text-gray-600" />
              </button>
            </div>
            <button 
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
            >
              {isFullscreen ? (
                <>
                  <Minimize2 className="w-4 h-4" />
                  Exit Full Screen
                </>
              ) : (
                <>
                  <Maximize2 className="w-4 h-4" />
                  Full Screen
                </>
              )}
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700">
              <Download className="w-4 h-4" />
              Export as SVG
            </button>
          </div>
        </div>

        {/* Legend */}
        {!isFullscreen && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
            <h3 className="text-gray-900 mb-4">Legend</h3>
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span className="text-sm text-gray-700">Critical Issue - Requires immediate attention</span>
              </div>
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-yellow-600" />
                <span className="text-sm text-gray-700">Warning - Review recommended</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600" />
                <span className="text-sm text-gray-700">Compatible - No issues found</span>
              </div>
            </div>
          </div>
        )}

        {/* Tree Visualization */}
        <div className={`bg-white rounded-lg shadow-sm border border-gray-200 p-8 ${isFullscreen ? 'h-[calc(100vh-180px)]' : ''}`}>
          <div 
            className="overflow-auto h-full" 
            style={{ 
              transform: `scale(${zoom / 100})`, 
              transformOrigin: 'top left',
              minHeight: isFullscreen ? 'auto' : '500px'
            }}
          >
            <div className="inline-block min-w-max">
              {renderTreeNode(treeData, true, '', true)}
            </div>
          </div>
        </div>

        {/* Summary Panel */}
        {!isFullscreen && (
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-3 mb-3">
                <AlertCircle className="w-5 h-5 text-red-600" />
                <h4 className="text-gray-900">Critical Dependencies</h4>
              </div>
              <div className="text-2xl text-gray-900 mb-2">3</div>
              <p className="text-sm text-gray-600">Packages with critical compatibility issues</p>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-3 mb-3">
                <AlertTriangle className="w-5 h-5 text-yellow-600" />
                <h4 className="text-gray-900">Warning Dependencies</h4>
              </div>
              <div className="text-2xl text-gray-900 mb-2">2</div>
              <p className="text-sm text-gray-600">Packages with warnings that need review</p>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-3 mb-3">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <h4 className="text-gray-900">Compatible Dependencies</h4>
              </div>
              <div className="text-2xl text-gray-900 mb-2">5</div>
              <p className="text-sm text-gray-600">Packages ready for migration</p>
            </div>
          </div>
        )}

        {/* Tips */}
        {!isFullscreen && (
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h4 className="text-blue-900 mb-3">How to use this view</h4>
            <div className="space-y-2 text-sm text-blue-700">
              <p>• Click on expand/collapse buttons or nodes to show/hide dependencies</p>
              <p>• Use zoom controls to adjust the view scale</p>
              <p>• Colors indicate severity: red (critical), yellow (warning), green (compatible)</p>
              <p>• Follow the tree lines to trace dependency paths</p>
              <p>• Export the tree as SVG for documentation purposes</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}