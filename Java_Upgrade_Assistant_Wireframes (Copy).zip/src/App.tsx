import { useState } from 'react';
import { Dashboard } from './components/Dashboard';
import { InternalDependenciesInput } from './components/InternalDependenciesInput';
import { LoadingState } from './components/LoadingState';
import { ResultsTable } from './components/ResultsTable';
import { DependencyTree } from './components/DependencyTree';

type Screen = 'dashboard' | 'input' | 'loading' | 'results' | 'tree' | 'error';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('dashboard');
  const [analysisData, setAnalysisData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = (url: string) => {
    setCurrentScreen('loading');
    setError(null);
    
    // Simulate API call
    setTimeout(() => {
      if (url.includes('error')) {
        setError('Failed to connect to Bitbucket repository. Please check the URL and try again.');
        setCurrentScreen('error');
      } else if (url.trim() === '') {
        setError('Please enter a valid Bitbucket repository URL.');
        setCurrentScreen('input');
      } else {
        // Mock successful analysis
        setAnalysisData({
          url,
          timestamp: new Date().toISOString(),
          totalDependencies: 47,
          criticalIssues: 12,
          warnings: 23,
          compatible: 12
        });
        setCurrentScreen('results');
      }
    }, 2500);
  };

  const navigateTo = (screen: Screen) => {
    setCurrentScreen(screen);
    if (screen === 'dashboard' || screen === 'input') {
      setError(null);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {currentScreen === 'dashboard' && (
        <Dashboard onNavigate={navigateTo} />
      )}
      {currentScreen === 'input' && (
        <InternalDependenciesInput 
          onAnalyze={handleAnalyze} 
          onBack={() => navigateTo('dashboard')}
          error={error}
        />
      )}
      {currentScreen === 'loading' && (
        <LoadingState />
      )}
      {currentScreen === 'results' && (
        <ResultsTable 
          data={analysisData}
          onNavigate={navigateTo}
        />
      )}
      {currentScreen === 'tree' && (
        <DependencyTree 
          data={analysisData}
          onNavigate={navigateTo}
        />
      )}
      {currentScreen === 'error' && (
        <InternalDependenciesInput 
          onAnalyze={handleAnalyze} 
          onBack={() => navigateTo('dashboard')}
          error={error}
        />
      )}
    </div>
  );
}
