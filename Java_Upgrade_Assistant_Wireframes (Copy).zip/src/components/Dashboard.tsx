import { Coffee, GitBranch, PackageSearch, TrendingUp, AlertCircle, CheckCircle2, Clock } from 'lucide-react';

interface DashboardProps {
  onNavigate: (screen: 'dashboard' | 'input' | 'loading' | 'results' | 'tree' | 'error') => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const recentAssessments = [
    { id: 1, name: 'payment-service', date: '2025-12-08', status: 'completed', issues: 8 },
    { id: 2, name: 'user-authentication', date: '2025-12-07', status: 'completed', issues: 15 },
    { id: 3, name: 'reporting-engine', date: '2025-12-06', status: 'completed', issues: 23 },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Coffee className="w-8 h-8 text-orange-600" />
              <div>
                <h1 className="text-gray-900">Java Upgrade Assistant</h1>
                <p className="text-sm text-gray-500">Streamline your Java migration</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <button className="text-gray-700 hover:text-gray-900">Dashboard</button>
              <button className="text-gray-700 hover:text-gray-900">Assessments</button>
              <button className="text-gray-700 hover:text-gray-900">Reports</button>
              <button className="text-gray-700 hover:text-gray-900">Settings</button>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-white">
                JD
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-gray-900 mb-2">Welcome back, Java Developer</h2>
          <p className="text-gray-600">Let&apos;s analyze your applications for Java upgrade compatibility</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center">
                <PackageSearch className="w-6 h-6 text-blue-600" />
              </div>
              <span className="text-sm text-gray-500">This month</span>
            </div>
            <div className="text-2xl text-gray-900 mb-1">24</div>
            <div className="text-sm text-gray-600">Total Assessments</div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-lg bg-red-100 flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-red-600" />
              </div>
              <span className="text-sm text-gray-500">Critical</span>
            </div>
            <div className="text-2xl text-gray-900 mb-1">156</div>
            <div className="text-sm text-gray-600">Issues Found</div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              </div>
              <span className="text-sm text-gray-500">Resolved</span>
            </div>
            <div className="text-2xl text-gray-900 mb-1">89</div>
            <div className="text-sm text-gray-600">Issues Fixed</div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
              <span className="text-sm text-gray-500">Progress</span>
            </div>
            <div className="text-2xl text-gray-900 mb-1">57%</div>
            <div className="text-sm text-gray-600">Migration Ready</div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h3 className="text-gray-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <button 
              onClick={() => onNavigate('input')}
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow text-left group"
            >
              <div className="w-12 h-12 rounded-lg bg-orange-100 flex items-center justify-center mb-4 group-hover:bg-orange-200 transition-colors">
                <GitBranch className="w-6 h-6 text-orange-600" />
              </div>
              <h4 className="text-gray-900 mb-2">Analyze Internal Dependencies</h4>
              <p className="text-sm text-gray-600">
                Connect your Bitbucket repository and analyze internal Java dependencies
              </p>
            </button>

            <button className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow text-left group">
              <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center mb-4 group-hover:bg-blue-200 transition-colors">
                <PackageSearch className="w-6 h-6 text-blue-600" />
              </div>
              <h4 className="text-gray-900 mb-2">Scan External Libraries</h4>
              <p className="text-sm text-gray-600">
                Identify third-party library compatibility with target Java version
              </p>
            </button>

            <button className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow text-left group">
              <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center mb-4 group-hover:bg-green-200 transition-colors">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
              <h4 className="text-gray-900 mb-2">Generate Migration Report</h4>
              <p className="text-sm text-gray-600">
                Create comprehensive upgrade recommendations and action plans
              </p>
            </button>
          </div>
        </div>

        {/* Recent Assessments */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-900">Recent Assessments</h3>
            <button className="text-sm text-orange-600 hover:text-orange-700">View All</button>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50">
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Project Name</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Date</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Status</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Issues Found</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {recentAssessments.map((assessment) => (
                  <tr key={assessment.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="px-6 py-4 text-gray-900">{assessment.name}</td>
                    <td className="px-6 py-4 text-gray-600 text-sm">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        {assessment.date}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm bg-green-100 text-green-700">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Completed
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm bg-red-100 text-red-700">
                        {assessment.issues}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <button className="text-sm text-orange-600 hover:text-orange-700">View Details</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
