import { Coffee, Loader2, CheckCircle2, Clock } from 'lucide-react';

export function LoadingState() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Coffee className="w-8 h-8 text-orange-600" />
              <div>
                <h1 className="text-gray-900">Java Upgrade Assistant</h1>
                <p className="text-sm text-gray-500">Streamline your Java migration</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <button className="text-gray-700 hover:text-gray-900">Dashboard</button>
              <button className="text-gray-700 hover:text-gray-900">Assessments</button>
              <button className="text-gray-700 hover:text-gray-900">Reports</button>
              <button className="text-gray-700 hover:text-gray-900">Settings</button>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-white">
                JD
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-16">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12">
          {/* Loading Spinner */}
          <div className="text-center mb-8">
            <div className="relative inline-block">
              <div className="w-20 h-20 rounded-full bg-orange-100 flex items-center justify-center mb-6">
                <Loader2 className="w-10 h-10 text-orange-600 animate-spin" />
              </div>
            </div>
            <h2 className="text-gray-900 mb-3">Analyzing Your Repository</h2>
            <p className="text-gray-600 max-w-md mx-auto">
              Please wait while we scan your codebase and analyze internal dependencies. This may take a few minutes.
            </p>
          </div>

          {/* Progress Steps */}
          <div className="max-w-xl mx-auto space-y-4 mb-8">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mt-1">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
              <div className="flex-1">
                <h4 className="text-gray-900 mb-1">Connected to Repository</h4>
                <p className="text-sm text-gray-600">Successfully authenticated with Bitbucket</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mt-1">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
              <div className="flex-1">
                <h4 className="text-gray-900 mb-1">Cloning Repository</h4>
                <p className="text-sm text-gray-600">Downloaded source code for analysis</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center mt-1">
                <Loader2 className="w-5 h-5 text-orange-600 animate-spin" />
              </div>
              <div className="flex-1">
                <h4 className="text-gray-900 mb-1">Scanning Dependencies</h4>
                <p className="text-sm text-gray-600">Analyzing internal package structure and dependencies</p>
                <div className="mt-3 bg-gray-100 rounded-full h-2 overflow-hidden">
                  <div className="bg-orange-600 h-full animate-pulse" style={{ width: '67%' }}></div>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center mt-1">
                <Clock className="w-5 h-5 text-gray-400" />
              </div>
              <div className="flex-1">
                <h4 className="text-gray-500 mb-1">Generating Report</h4>
                <p className="text-sm text-gray-500">Compiling analysis results and recommendations</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center mt-1">
                <Clock className="w-5 h-5 text-gray-400" />
              </div>
              <div className="flex-1">
                <h4 className="text-gray-500 mb-1">Building Dependency Tree</h4>
                <p className="text-sm text-gray-500">Creating visualization of dependency relationships</p>
              </div>
            </div>
          </div>

          {/* Estimated Time */}
          <div className="text-center pt-6 border-t border-gray-200">
            <div className="inline-flex items-center gap-2 text-sm text-gray-600 bg-gray-50 px-4 py-2 rounded-full">
              <Clock className="w-4 h-4" />
              <span>Estimated time remaining: 1-2 minutes</span>
            </div>
          </div>
        </div>

        {/* Tips Section */}
        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h4 className="text-blue-900 mb-3">While you wait...</h4>
          <div className="space-y-2 text-sm text-blue-700">
            <p>• The analysis will identify all internal package dependencies</p>
            <p>• Critical compatibility issues will be highlighted for your review</p>
            <p>• You&apos;ll receive actionable recommendations for each finding</p>
            <p>• Results can be exported to CSV or PDF for team collaboration</p>
          </div>
        </div>
      </div>
    </div>
  );
}
