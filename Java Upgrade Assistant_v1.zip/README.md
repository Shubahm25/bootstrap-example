
  # Java Upgrade Assistant Wireframes

  This is a code bundle for Java Upgrade Assistant Wireframes. The original project is available at https://www.figma.com/design/mrxtfqYFmGJr7ynTnS1sRE/Java-Upgrade-Assistant-Wireframes.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  