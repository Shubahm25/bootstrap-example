import { Coffee, ArrowLeft, Download, Clock, AlertCircle, AlertTriangle, CheckCircle2, GitBranch, FileCode, TrendingUp } from 'lucide-react';

interface AssessmentDetailsProps {
  assessmentId: number | null;
  onNavigate: (screen: 'dashboard' | 'input' | 'external-input' | 'loading' | 'results' | 'tree' | 'error' | 'assessments' | 'assessment-details') => void;
}

export function AssessmentDetails({ assessmentId, onNavigate }: AssessmentDetailsProps) {
  // Mock data based on assessment ID
  const assessmentData = {
    1: {
      name: 'payment-service',
      type: 'Internal Dependencies',
      date: '2025-12-08',
      duration: '3m 24s',
      repository: 'https://bitbucket.org/company/payment-service',
      currentJavaVersion: '8',
      targetJavaVersion: '17',
      totalDependencies: 47,
      criticalIssues: 8,
      warnings: 12,
      compatible: 27,
      topIssues: [
        { package: 'com.example.payment.processor', issue: 'Uses removed API: sun.misc.BASE64Encoder', severity: 'critical' },
        { package: 'com.example.encryption.utils', issue: 'Reflection usage requires --add-opens flag', severity: 'critical' },
        { package: 'com.example.validation', issue: 'Deprecated method usage', severity: 'warning' },
      ]
    },
    2: {
      name: 'user-authentication',
      type: 'Internal Dependencies',
      date: '2025-12-07',
      duration: '2m 45s',
      repository: 'https://bitbucket.org/company/user-authentication',
      currentJavaVersion: '11',
      targetJavaVersion: '17',
      totalDependencies: 34,
      criticalIssues: 15,
      warnings: 8,
      compatible: 11,
      topIssues: [
        { package: 'com.example.security.jwt', issue: 'Deprecated security provider', severity: 'critical' },
        { package: 'com.example.user.session', issue: 'Unsafe deserialization detected', severity: 'critical' },
        { package: 'com.example.oauth', issue: 'Update OAuth library version', severity: 'warning' },
      ]
    },
    3: {
      name: 'reporting-engine',
      type: 'External Libraries',
      date: '2025-12-06',
      duration: '4m 12s',
      repository: 'https://bitbucket.org/company/reporting-engine',
      currentJavaVersion: '8',
      targetJavaVersion: '21',
      totalDependencies: 52,
      criticalIssues: 23,
      warnings: 19,
      compatible: 10,
      topIssues: [
        { package: 'org.apache.poi:poi', issue: 'Version 3.x incompatible with Java 21', severity: 'critical' },
        { package: 'com.itextpdf:itextpdf', issue: 'Security vulnerability in version 5.x', severity: 'critical' },
        { package: 'net.sf.jasperreports', issue: 'Update to latest version required', severity: 'warning' },
      ]
    }
  };

  const assessment = assessmentData[assessmentId as keyof typeof assessmentData] || assessmentData[1];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Coffee className="w-8 h-8 text-orange-600" />
              <div>
                <h1 className="text-gray-900">Java Upgrade Assistant</h1>
                <p className="text-sm text-gray-500">Streamline your Java migration</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <button 
                onClick={() => onNavigate('dashboard')}
                className="text-gray-700 hover:text-gray-900"
              >
                Dashboard
              </button>
              <button 
                onClick={() => onNavigate('assessments')}
                className="text-gray-700 hover:text-gray-900"
              >
                Assessments
              </button>
              <button className="text-gray-700 hover:text-gray-900">Reports</button>
              <button className="text-gray-700 hover:text-gray-900">Settings</button>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-white">
                JD
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Back Button */}
        <button 
          onClick={() => onNavigate('assessments')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Assessments
        </button>

        {/* Page Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-gray-900 mb-2">{assessment.name}</h2>
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  {assessment.date}
                </div>
                <span>•</span>
                <span>{assessment.type}</span>
                <span>•</span>
                <span>Duration: {assessment.duration}</span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                <GitBranch className="w-4 h-4" />
                View Repository
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700">
                <Download className="w-4 h-4" />
                Download Report
              </button>
            </div>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {/* Migration Info */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-gray-900 mb-4">Migration Overview</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Current Version:</span>
                <span className="text-gray-900">Java {assessment.currentJavaVersion}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Target Version:</span>
                <span className="text-gray-900">Java {assessment.targetJavaVersion}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Repository:</span>
                <span className="text-blue-600 text-sm truncate max-w-xs">{assessment.repository}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Analysis Date:</span>
                <span className="text-gray-900">{assessment.date}</span>
              </div>
            </div>
          </div>

          {/* Status Card */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-gray-900 mb-4">Status</h3>
            <div className="flex items-center gap-3 mb-4">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
              <span className="text-gray-900">Analysis Completed Successfully</span>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Migration Readiness</span>
                <span className="text-sm text-gray-900">57%</span>
              </div>
              <div className="bg-gray-200 rounded-full h-2">
                <div className="bg-orange-600 h-2 rounded-full" style={{ width: '57%' }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-3">
              <FileCode className="w-5 h-5 text-blue-600" />
              <span className="text-sm text-gray-600">Total</span>
            </div>
            <div className="text-2xl text-gray-900 mb-1">{assessment.totalDependencies}</div>
            <div className="text-sm text-gray-600">Dependencies</div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-3">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <span className="text-sm text-gray-600">Critical</span>
            </div>
            <div className="text-2xl text-red-600 mb-1">{assessment.criticalIssues}</div>
            <div className="text-sm text-gray-600">Issues</div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-3">
              <AlertTriangle className="w-5 h-5 text-yellow-600" />
              <span className="text-sm text-gray-600">Warning</span>
            </div>
            <div className="text-2xl text-yellow-600 mb-1">{assessment.warnings}</div>
            <div className="text-sm text-gray-600">Issues</div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-3 mb-3">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
              <span className="text-sm text-gray-600">Compatible</span>
            </div>
            <div className="text-2xl text-green-600 mb-1">{assessment.compatible}</div>
            <div className="text-sm text-gray-600">Dependencies</div>
          </div>
        </div>

        {/* Top Issues */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-gray-900">Top Issues</h3>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {assessment.topIssues.map((issue, index) => (
                <div key={index} className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                  <div className="flex-shrink-0 mt-1">
                    {issue.severity === 'critical' ? (
                      <AlertCircle className="w-5 h-5 text-red-600" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-yellow-600" />
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-gray-900">{issue.package}</h4>
                      <span className={`inline-flex px-2 py-0.5 rounded text-xs ${
                        issue.severity === 'critical' 
                          ? 'bg-red-100 text-red-700' 
                          : 'bg-yellow-100 text-yellow-700'
                      }`}>
                        {issue.severity}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">{issue.issue}</p>
                  </div>
                  <button className="text-sm text-orange-600 hover:text-orange-700">
                    View Solution
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recommendations */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-gray-900">Recommendations</h3>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <TrendingUp className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-gray-900 mb-1">Update Dependencies First</h4>
                  <p className="text-sm text-gray-600">
                    Start by updating all third-party libraries to their latest Java {assessment.targetJavaVersion}-compatible versions
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <TrendingUp className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-gray-900 mb-1">Address Critical Issues</h4>
                  <p className="text-sm text-gray-600">
                    Focus on the {assessment.criticalIssues} critical issues that will block migration
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <TrendingUp className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-gray-900 mb-1">Run Comprehensive Tests</h4>
                  <p className="text-sm text-gray-600">
                    Execute full test suite after each fix to ensure compatibility
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <TrendingUp className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-gray-900 mb-1">Estimated Migration Time</h4>
                  <p className="text-sm text-gray-600">
                    Based on the analysis, estimated migration effort is 2-3 weeks with a team of 2 developers
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
