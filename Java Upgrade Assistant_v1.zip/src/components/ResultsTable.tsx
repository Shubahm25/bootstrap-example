import { useState } from 'react';
import { Coffee, Download, Filter, Search, AlertCircle, AlertTriangle, CheckCircle2, ChevronDown, Eye, ArrowLeft, GitBranch, FileJson, FileSpreadsheet } from 'lucide-react';

interface ResultsTableProps {
  data: any;
  onNavigate: (screen: 'dashboard' | 'input' | 'loading' | 'results' | 'tree' | 'error') => void;
}

export function ResultsTable({ data, onNavigate }: ResultsTableProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [showExportMenu, setShowExportMenu] = useState(false);

  // Mock dependency data
  const dependencies = [
    {
      id: 1,
      package: 'com.example.payment.processor',
      dependsOn: 'com.example.core.utils',
      severity: 'critical',
      status: 'incompatible',
      issue: 'Uses removed API: sun.misc.BASE64Encoder',
      javaVersion: 'Java 11+',
      effort: 'High'
    },
    {
      id: 2,
      package: 'com.example.user.authentication',
      dependsOn: 'com.example.security.jwt',
      severity: 'warning',
      status: 'warning',
      issue: 'Deprecated method usage in security module',
      javaVersion: 'Java 17+',
      effort: 'Medium'
    },
    {
      id: 3,
      package: 'com.example.reporting.engine',
      dependsOn: 'com.example.data.export',
      severity: 'compatible',
      status: 'compatible',
      issue: 'No issues found',
      javaVersion: 'Java 21',
      effort: 'None'
    },
    {
      id: 4,
      package: 'com.example.notification.service',
      dependsOn: 'com.example.messaging.queue',
      severity: 'critical',
      status: 'incompatible',
      issue: 'Reflection usage requires --add-opens flag',
      javaVersion: 'Java 17+',
      effort: 'High'
    },
    {
      id: 5,
      package: 'com.example.inventory.manager',
      dependsOn: 'com.example.database.connector',
      severity: 'warning',
      status: 'warning',
      issue: 'JDBC driver version needs update',
      javaVersion: 'Java 17+',
      effort: 'Low'
    },
    {
      id: 6,
      package: 'com.example.analytics.tracker',
      dependsOn: 'com.example.core.logging',
      severity: 'compatible',
      status: 'compatible',
      issue: 'No issues found',
      javaVersion: 'Java 21',
      effort: 'None'
    },
    {
      id: 7,
      package: 'com.example.file.storage',
      dependsOn: 'com.example.aws.s3client',
      severity: 'warning',
      status: 'warning',
      issue: 'Update AWS SDK to version 2.x',
      javaVersion: 'Java 17+',
      effort: 'Medium'
    },
    {
      id: 8,
      package: 'com.example.email.sender',
      dependsOn: 'com.example.template.engine',
      severity: 'compatible',
      status: 'compatible',
      issue: 'No issues found',
      javaVersion: 'Java 21',
      effort: 'None'
    },
  ];

  const filteredDependencies = dependencies.filter(dep => {
    const matchesSearch = 
      dep.package.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dep.dependsOn.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dep.issue.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || dep.status === statusFilter;
    const matchesSeverity = severityFilter === 'all' || dep.severity === severityFilter;
    
    return matchesSearch && matchesStatus && matchesSeverity;
  });

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'critical':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm bg-red-100 text-red-700">
            <AlertCircle className="w-3.5 h-3.5" />
            Critical
          </span>
        );
      case 'warning':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm bg-yellow-100 text-yellow-700">
            <AlertTriangle className="w-3.5 h-3.5" />
            Warning
          </span>
        );
      case 'compatible':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm bg-green-100 text-green-700">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Compatible
          </span>
        );
      default:
        return null;
    }
  };

  const exportToJSON = () => {
    const exportData = {
      metadata: {
        exportDate: new Date().toISOString(),
        repositoryUrl: data?.url || 'N/A',
        analysisDate: data?.timestamp || new Date().toISOString(),
        totalDependencies: data?.totalDependencies || 47,
        criticalIssues: data?.criticalIssues || 12,
        warnings: data?.warnings || 23,
        compatible: data?.compatible || 12
      },
      dependencies: filteredDependencies.map(dep => ({
        package: dep.package,
        dependsOn: dep.dependsOn,
        severity: dep.severity,
        status: dep.status,
        issue: dep.issue,
        targetJavaVersion: dep.javaVersion,
        migrationEffort: dep.effort
      }))
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `java-dependencies-report-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  };

  const exportToCSV = () => {
    const headers = ['Package', 'Depends On', 'Severity', 'Status', 'Issue', 'Target Java Version', 'Migration Effort'];
    const csvRows = [
      headers.join(','),
      ...filteredDependencies.map(dep => {
        return [
          `"${dep.package}"`,
          `"${dep.dependsOn}"`,
          dep.severity,
          dep.status,
          `"${dep.issue}"`,
          `"${dep.javaVersion}"`,
          dep.effort
        ].join(',');
      })
    ];

    const csvContent = csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `java-dependencies-report-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Coffee className="w-8 h-8 text-orange-600" />
              <div>
                <h1 className="text-gray-900">Java Upgrade Assistant</h1>
                <p className="text-sm text-gray-500">Streamline your Java migration</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <button className="text-gray-700 hover:text-gray-900">Dashboard</button>
              <button className="text-gray-700 hover:text-gray-900">Assessments</button>
              <button className="text-gray-700 hover:text-gray-900">Reports</button>
              <button className="text-gray-700 hover:text-gray-900">Settings</button>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-white">
                JD
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Back Button */}
        <button 
          onClick={() => onNavigate('dashboard')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </button>

        {/* Page Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-gray-900 mb-2">Internal Dependencies Analysis</h2>
              <p className="text-gray-600">Analysis completed on {new Date().toLocaleString()}</p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => onNavigate('tree')}
                className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <GitBranch className="w-4 h-4" />
                View Dependency Tree
              </button>
              <div className="relative">
                <button
                  onClick={() => setShowExportMenu(!showExportMenu)}
                  className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  Export Report
                </button>
                {showExportMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 z-10">
                    <button
                      onClick={exportToJSON}
                      className="flex items-center gap-2 px-4 py-3 text-gray-700 hover:bg-gray-50 w-full text-left rounded-t-lg transition-colors"
                    >
                      <FileJson className="w-4 h-4" />
                      Export as JSON
                    </button>
                    <button
                      onClick={exportToCSV}
                      className="flex items-center gap-2 px-4 py-3 text-gray-700 hover:bg-gray-50 w-full text-left rounded-b-lg transition-colors"
                    >
                      <FileSpreadsheet className="w-4 h-4" />
                      Export as CSV
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="text-2xl text-gray-900 mb-1">{data?.totalDependencies || 47}</div>
            <div className="text-sm text-gray-600">Total Dependencies</div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="text-2xl text-red-600 mb-1">{data?.criticalIssues || 12}</div>
            <div className="text-sm text-gray-600">Critical Issues</div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="text-2xl text-yellow-600 mb-1">{data?.warnings || 23}</div>
            <div className="text-sm text-gray-600">Warnings</div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="text-2xl text-green-600 mb-1">{data?.compatible || 12}</div>
            <div className="text-sm text-gray-600">Compatible</div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm text-gray-700 mb-2">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search packages, dependencies, or issues..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm text-gray-700 mb-2">Severity</label>
              <div className="relative">
                <select
                  value={severityFilter}
                  onChange={(e) => setSeverityFilter(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 appearance-none"
                >
                  <option value="all">All Severities</option>
                  <option value="critical">Critical</option>
                  <option value="warning">Warning</option>
                  <option value="compatible">Compatible</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
              </div>
            </div>
            <div>
              <label className="block text-sm text-gray-700 mb-2">Status</label>
              <div className="relative">
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 appearance-none"
                >
                  <option value="all">All Statuses</option>
                  <option value="incompatible">Incompatible</option>
                  <option value="warning">Warning</option>
                  <option value="compatible">Compatible</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200">
            <div className="text-sm text-gray-600">
              Showing {filteredDependencies.length} of {dependencies.length} dependencies
            </div>
            <button className="flex items-center gap-2 text-sm text-orange-600 hover:text-orange-700">
              <Filter className="w-4 h-4" />
              Reset Filters
            </button>
          </div>
        </div>

        {/* Results Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50">
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Package</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Depends On</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Severity</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Issue</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Target Version</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Effort</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredDependencies.map((dep) => (
                  <tr key={dep.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="text-gray-900">{dep.package}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-gray-600 text-sm">{dep.dependsOn}</div>
                    </td>
                    <td className="px-6 py-4">
                      {getSeverityBadge(dep.severity)}
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-700 max-w-xs">{dep.issue}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-600">{dep.javaVersion}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-600">{dep.effort}</div>
                    </td>
                    <td className="px-6 py-4">
                      <button className="flex items-center gap-1 text-sm text-orange-600 hover:text-orange-700">
                        <Eye className="w-4 h-4" />
                        Details
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="border-t border-gray-200 px-6 py-4 flex items-center justify-between">
            <div className="text-sm text-gray-600">
              Page 1 of 1
            </div>
            <div className="flex items-center gap-2">
              <button className="px-3 py-1 border border-gray-300 rounded text-sm text-gray-400 cursor-not-allowed">
                Previous
              </button>
              <button className="px-3 py-1 bg-orange-600 text-white rounded text-sm">
                1
              </button>
              <button className="px-3 py-1 border border-gray-300 rounded text-sm text-gray-400 cursor-not-allowed">
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}