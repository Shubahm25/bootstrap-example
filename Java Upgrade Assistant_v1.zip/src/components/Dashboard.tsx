import { Coffee, GitBranch, PackageSearch, TrendingUp, AlertCircle, CheckCircle2, Clock, Calculator, FolderOpen, Check, X } from 'lucide-react';
import { useState } from 'react';

interface DashboardProps {
  onNavigate: (screen: 'dashboard' | 'input' | 'external-input' | 'loading' | 'results' | 'tree' | 'error' | 'assessments' | 'assessment-details', assessmentId?: number) => void;
  onCheckout: (repoName: string, url: string, targetLocation: string) => void;
  repoData: { repoName: string; url: string; targetLocation: string } | null;
}

export function Dashboard({ onNavigate, onCheckout, repoData }: DashboardProps) {
  const [repoName, setRepoName] = useState('');
  const [cloneUrl, setCloneUrl] = useState('');
  const [targetLocation, setTargetLocation] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);
  const [showModal, setShowModal] = useState(false);
  
  const recentAssessments = [
    { id: 1, name: 'payment-service', date: '2025-12-08', status: 'completed', issues: 8 },
    { id: 2, name: 'user-authentication', date: '2025-12-07', status: 'completed', issues: 15 },
    { id: 3, name: 'reporting-engine', date: '2025-12-06', status: 'completed', issues: 23 },
  ];

  const handleFolderBrowse = () => {
    // In a real app, this would open a native folder picker dialog
    // For this demo, we'll simulate folder selection
    const input = document.createElement('input');
    input.type = 'file';
    input.webkitdirectory = true;
    input.onchange = (e: any) => {
      const files = e.target.files;
      if (files.length > 0) {
        // Get the path from the first file (this is a simulation)
        const path = files[0].webkitRelativePath?.split('/')[0] || '/local/projects';
        setTargetLocation(`/local/projects/${path}`);
      }
    };
    input.click();
  };

  const handleCheckout = () => {
    if (cloneUrl && targetLocation) {
      setShowSuccess(true);
      onCheckout(repoName, cloneUrl, targetLocation);
      setTimeout(() => {
        setShowSuccess(false);
      }, 5000);
    }
  };

  const handleAnalysisNavigation = (screen: 'input' | 'external-input') => {
    // Check if project exists (simulated check)
    if (repoData && repoData.targetLocation) {
      onNavigate(screen);
    } else {
      setShowModal(true);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Coffee className="w-8 h-8 text-orange-600" />
              <div>
                <h1 className="text-gray-900">Java Upgrade Assistant</h1>
                <p className="text-sm text-gray-500">Streamline your Java migration</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <button className="text-gray-700 hover:text-gray-900">Dashboard</button>
              <button className="text-gray-700 hover:text-gray-900">Assessments</button>
              <button className="text-gray-700 hover:text-gray-900">Reports</button>
              <button className="text-gray-700 hover:text-gray-900">Settings</button>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-white">
                JD
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-gray-900 mb-2">Welcome back, Java Developer</h2>
          <p className="text-gray-600">Let&apos;s analyze your applications for Java upgrade compatibility</p>
        </div>

        {/* Clone Repository Section */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
          <h3 className="text-gray-900 mb-4">Clone Repository</h3>
          
          {/* Success Message */}
          {showSuccess && (
            <div className="mb-4 bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <h4 className="text-green-900 mb-1">Project is cloned successfully</h4>
                  <p className="text-sm text-green-700">
                    You can now analyze internal dependencies or external libraries
                  </p>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-4">
            {/* Repository Name Input */}
            <div>
              <label htmlFor="repo-name" className="block text-sm text-gray-700 mb-2">
                Repository Name
              </label>
              <input
                id="repo-name"
                type="text"
                value={repoName}
                onChange={(e) => setRepoName(e.target.value)}
                placeholder="e.g., my-java-project"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            {/* Clone URL Input */}
            <div>
              <label htmlFor="clone-url" className="block text-sm text-gray-700 mb-2">
                Bitbucket Repository URL
              </label>
              <input
                id="clone-url"
                type="text"
                value={cloneUrl}
                onChange={(e) => setCloneUrl(e.target.value)}
                placeholder="https://bitbucket.org/your-org/your-repo"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            {/* Target Location Folder Browser */}
            <div>
              <label className="block text-sm text-gray-700 mb-2">
                Target Location
              </label>
              <div className="flex gap-3">
                <input
                  type="text"
                  value={targetLocation}
                  readOnly
                  placeholder="Select folder where to clone the project"
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
                <button
                  onClick={handleFolderBrowse}
                  className="px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2"
                >
                  <FolderOpen className="w-5 h-5 text-gray-600" />
                  Browse
                </button>
              </div>
              <p className="text-sm text-gray-500 mt-2">
                Choose a local folder to clone the repository
              </p>
            </div>

            {/* Checkout Button */}
            <div>
              <button
                onClick={handleCheckout}
                disabled={!cloneUrl || !targetLocation}
                className={`px-6 py-3 rounded-lg transition-colors ${
                  !cloneUrl || !targetLocation
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-orange-600 text-white hover:bg-orange-700'
                }`}
              >
                Checkout
              </button>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h3 className="text-gray-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <button 
              onClick={() => handleAnalysisNavigation('input')}
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow text-left group"
            >
              <div className="w-12 h-12 rounded-lg bg-orange-100 flex items-center justify-center mb-4 group-hover:bg-orange-200 transition-colors">
                <GitBranch className="w-6 h-6 text-orange-600" />
              </div>
              <h4 className="text-gray-900 mb-2">Analyze Internal Dependencies</h4>
              <p className="text-sm text-gray-600">
                Connect your Bitbucket repository and analyze internal Java dependencies
              </p>
            </button>

            <button 
              onClick={() => handleAnalysisNavigation('external-input')}
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow text-left group"
            >
              <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center mb-4 group-hover:bg-blue-200 transition-colors">
                <PackageSearch className="w-6 h-6 text-blue-600" />
              </div>
              <h4 className="text-gray-900 mb-2">Scan External Libraries</h4>
              <p className="text-sm text-gray-600">
                Identify third-party library compatibility with target Java version
              </p>
            </button>

            <button className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow text-left group">
              <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center mb-4 group-hover:bg-green-200 transition-colors">
                <Calculator className="w-6 h-6 text-green-600" />
              </div>
              <h4 className="text-gray-900 mb-2">Estimation Tool</h4>
              <p className="text-sm text-gray-600">
                Calculate migration effort and create comprehensive upgrade recommendations
              </p>
            </button>
          </div>
        </div>

        {/* Recent Assessments */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-900">Recent Assessments</h3>
            <button 
              onClick={() => onNavigate('assessments')}
              className="text-sm text-orange-600 hover:text-orange-700"
            >
              View All
            </button>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50">
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Project Name</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Date</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Status</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Issues Found</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {recentAssessments.map((assessment) => (
                  <tr key={assessment.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="px-6 py-4 text-gray-900">{assessment.name}</td>
                    <td className="px-6 py-4 text-gray-600 text-sm">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        {assessment.date}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm bg-green-100 text-green-700">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Completed
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm bg-red-100 text-red-700">
                        {assessment.issues}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <button 
                        onClick={() => onNavigate('assessment-details', assessment.id)}
                        className="text-sm text-orange-600 hover:text-orange-700"
                      >
                        View Details
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Modal for checkout warning */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full mx-4">
            <div className="p-6">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
                  <AlertCircle className="w-6 h-6 text-orange-600" />
                </div>
                <div className="flex-1">
                  <h3 className="text-gray-900 mb-2">Project Not Found</h3>
                  <p className="text-sm text-gray-600">
                    Please checkout the project first before analyzing dependencies or libraries.
                  </p>
                </div>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                >
                  Got it
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}