import { useState } from 'react';
import { Coffee, Search, Filter, ChevronDown, Clock, CheckCircle2, AlertCircle, Eye, Trash2 } from 'lucide-react';

interface AssessmentsPageProps {
  onNavigate: (screen: 'dashboard' | 'input' | 'external-input' | 'loading' | 'results' | 'tree' | 'error' | 'assessments' | 'assessment-details', assessmentId?: number) => void;
}

export function AssessmentsPage({ onNavigate }: AssessmentsPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const allAssessments = [
    { id: 1, name: 'payment-service', type: 'Internal Dependencies', date: '2025-12-08', status: 'completed', issues: 8, duration: '3m 24s' },
    { id: 2, name: 'user-authentication', type: 'Internal Dependencies', date: '2025-12-07', status: 'completed', issues: 15, duration: '2m 45s' },
    { id: 3, name: 'reporting-engine', type: 'External Libraries', date: '2025-12-06', status: 'completed', issues: 23, duration: '4m 12s' },
    { id: 4, name: 'notification-service', type: 'Internal Dependencies', date: '2025-12-05', status: 'completed', issues: 12, duration: '3m 08s' },
    { id: 5, name: 'analytics-platform', type: 'External Libraries', date: '2025-12-04', status: 'completed', issues: 34, duration: '5m 31s' },
    { id: 6, name: 'data-processor', type: 'Internal Dependencies', date: '2025-12-03', status: 'completed', issues: 6, duration: '2m 18s' },
    { id: 7, name: 'api-gateway', type: 'External Libraries', date: '2025-12-02', status: 'completed', issues: 19, duration: '3m 42s' },
    { id: 8, name: 'inventory-manager', type: 'Internal Dependencies', date: '2025-12-01', status: 'completed', issues: 11, duration: '2m 56s' },
    { id: 9, name: 'email-sender', type: 'External Libraries', date: '2025-11-30', status: 'completed', issues: 4, duration: '1m 52s' },
    { id: 10, name: 'file-storage', type: 'Internal Dependencies', date: '2025-11-29', status: 'completed', issues: 27, duration: '4m 35s' },
  ];

  const filteredAssessments = allAssessments.filter(assessment => {
    const matchesSearch = assessment.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || assessment.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Coffee className="w-8 h-8 text-orange-600" />
              <div>
                <h1 className="text-gray-900">Java Upgrade Assistant</h1>
                <p className="text-sm text-gray-500">Streamline your Java migration</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <button 
                onClick={() => onNavigate('dashboard')}
                className="text-gray-700 hover:text-gray-900"
              >
                Dashboard
              </button>
              <button className="text-orange-600">Assessments</button>
              <button className="text-gray-700 hover:text-gray-900">Reports</button>
              <button className="text-gray-700 hover:text-gray-900">Settings</button>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-white">
                JD
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Page Header */}
        <div className="mb-6">
          <h2 className="text-gray-900 mb-2">All Assessments</h2>
          <p className="text-gray-600">View and manage all your Java upgrade assessments</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="text-2xl text-gray-900 mb-1">{allAssessments.length}</div>
            <div className="text-sm text-gray-600">Total Assessments</div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="text-2xl text-green-600 mb-1">{allAssessments.filter(a => a.status === 'completed').length}</div>
            <div className="text-sm text-gray-600">Completed</div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="text-2xl text-red-600 mb-1">{allAssessments.reduce((sum, a) => sum + a.issues, 0)}</div>
            <div className="text-sm text-gray-600">Total Issues</div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="text-2xl text-gray-900 mb-1">3.2</div>
            <div className="text-sm text-gray-600">Avg. Duration (min)</div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm text-gray-700 mb-2">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by project name..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm text-gray-700 mb-2">Status</label>
              <div className="relative">
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 appearance-none"
                >
                  <option value="all">All Status</option>
                  <option value="completed">Completed</option>
                  <option value="in-progress">In Progress</option>
                  <option value="failed">Failed</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200">
            <div className="text-sm text-gray-600">
              Showing {filteredAssessments.length} of {allAssessments.length} assessments
            </div>
            <button className="flex items-center gap-2 text-sm text-orange-600 hover:text-orange-700">
              <Filter className="w-4 h-4" />
              Reset Filters
            </button>
          </div>
        </div>

        {/* Assessments Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50">
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Project Name</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Type</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Date</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Status</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Issues</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Duration</th>
                  <th className="text-left px-6 py-3 text-sm text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredAssessments.map((assessment) => (
                  <tr key={assessment.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="px-6 py-4 text-gray-900">{assessment.name}</td>
                    <td className="px-6 py-4">
                      <span className="inline-flex px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-700">
                        {assessment.type}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-gray-600 text-sm">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        {assessment.date}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm bg-green-100 text-green-700">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Completed
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm ${
                        assessment.issues > 20 ? 'bg-red-100 text-red-700' :
                        assessment.issues > 10 ? 'bg-yellow-100 text-yellow-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {assessment.issues > 20 && <AlertCircle className="w-3.5 h-3.5" />}
                        {assessment.issues}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">{assessment.duration}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <button 
                          onClick={() => onNavigate('assessment-details', assessment.id)}
                          className="text-orange-600 hover:text-orange-700"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="text-gray-400 hover:text-red-600">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="border-t border-gray-200 px-6 py-4 flex items-center justify-between">
            <div className="text-sm text-gray-600">
              Page 1 of 1
            </div>
            <div className="flex items-center gap-2">
              <button className="px-3 py-1 border border-gray-300 rounded text-sm text-gray-400 cursor-not-allowed">
                Previous
              </button>
              <button className="px-3 py-1 bg-orange-600 text-white rounded text-sm">
                1
              </button>
              <button className="px-3 py-1 border border-gray-300 rounded text-sm text-gray-400 cursor-not-allowed">
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
