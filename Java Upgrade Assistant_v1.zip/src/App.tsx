import { useState } from 'react';
import { Dashboard } from './components/Dashboard';
import { InternalDependenciesInput } from './components/InternalDependenciesInput';
import { ExternalLibrariesInput } from './components/ExternalLibrariesInput';
import { FileBrowser } from './components/FileBrowser';
import { LoadingState } from './components/LoadingState';
import { ResultsTable } from './components/ResultsTable';
import { DependencyTree } from './components/DependencyTree';
import { AssessmentsPage } from './components/AssessmentsPage';
import { AssessmentDetails } from './components/AssessmentDetails';

type Screen = 'dashboard' | 'input' | 'external-input' | 'file-browser' | 'loading' | 'results' | 'tree' | 'error' | 'assessments' | 'assessment-details';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('dashboard');
  const [analysisData, setAnalysisData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedAssessmentId, setSelectedAssessmentId] = useState<number | null>(null);
  const [repositoryUrl, setRepositoryUrl] = useState<string>('');
  const [analysisType, setAnalysisType] = useState<'internal' | 'external'>('internal');
  const [isRepositoryCloned, setIsRepositoryCloned] = useState<boolean>(false);
  const [repoData, setRepoData] = useState<{ repoName: string; url: string; targetLocation: string } | null>(null);

  const handleCheckout = (repoName: string, url: string, targetLocation: string) => {
    setRepoData({ repoName, url, targetLocation });
    setRepositoryUrl(url);
    setIsRepositoryCloned(true);
  };

  const handleNavigateToAnalysis = (screen: Screen, assessmentId?: number) => {
    // If navigating to internal or external input and repository is cloned, go directly to file browser
    if (isRepositoryCloned && (screen === 'input' || screen === 'external-input')) {
      setAnalysisType(screen === 'input' ? 'internal' : 'external');
      setCurrentScreen('file-browser');
    } else {
      setCurrentScreen(screen);
    }
    
    if (assessmentId) {
      setSelectedAssessmentId(assessmentId);
    }
    if (screen === 'dashboard') {
      setError(null);
    }
  };

  const navigateTo = (screen: Screen, assessmentId?: number) => {
    setCurrentScreen(screen);
    if (assessmentId) {
      setSelectedAssessmentId(assessmentId);
    }
    if (screen === 'dashboard') {
      setError(null);
      setRepositoryUrl('');
      setIsRepositoryCloned(false);
    }
  };

  const handleCloneRepository = (url: string, type: 'internal' | 'external') => {
    setRepositoryUrl(url);
    setAnalysisType(type);
    setCurrentScreen('loading');
    setError(null);
    
    // Simulate cloning repository
    setTimeout(() => {
      if (url.includes('error')) {
        setError('Failed to clone repository. Please check the URL and try again.');
        setCurrentScreen(type === 'internal' ? 'input' : 'external-input');
      } else {
        setCurrentScreen('file-browser');
      }
    }, 2000);
  };

  const handleAnalyze = (selectedFiles: string[]) => {
    setCurrentScreen('loading');
    setError(null);
    
    // Simulate API call
    setTimeout(() => {
      // Mock successful analysis
      setAnalysisData({
        url: repositoryUrl,
        files: selectedFiles,
        timestamp: new Date().toISOString(),
        totalDependencies: 47,
        criticalIssues: 12,
        warnings: 23,
        compatible: 12,
        type: analysisType
      });
      setCurrentScreen('results');
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {currentScreen === 'dashboard' && (
        <Dashboard 
          onNavigate={handleNavigateToAnalysis} 
          onCheckout={handleCheckout} 
          repoData={repoData}
        />
      )}
      {currentScreen === 'input' && (
        <InternalDependenciesInput 
          repoData={repoData}
          onCloneRepository={(url) => handleCloneRepository(url, 'internal')} 
          onBack={() => navigateTo('dashboard')}
          error={error}
        />
      )}
      {currentScreen === 'external-input' && (
        <ExternalLibrariesInput 
          repoData={repoData}
          onCloneRepository={(url) => handleCloneRepository(url, 'external')} 
          onBack={() => navigateTo('dashboard')}
          error={error}
        />
      )}
      {currentScreen === 'file-browser' && (
        <FileBrowser
          repositoryUrl={repositoryUrl}
          analysisType={analysisType}
          onAnalyze={handleAnalyze}
          onBack={() => navigateTo('dashboard')}
        />
      )}
      {currentScreen === 'loading' && (
        <LoadingState />
      )}
      {currentScreen === 'results' && (
        <ResultsTable 
          data={analysisData}
          onNavigate={navigateTo}
        />
      )}
      {currentScreen === 'tree' && (
        <DependencyTree 
          data={analysisData}
          onNavigate={navigateTo}
        />
      )}
      {currentScreen === 'assessments' && (
        <AssessmentsPage 
          onNavigate={navigateTo}
        />
      )}
      {currentScreen === 'assessment-details' && (
        <AssessmentDetails 
          assessmentId={selectedAssessmentId}
          onNavigate={navigateTo}
        />
      )}
      {currentScreen === 'error' && (
        <InternalDependenciesInput 
          repoData={repoData}
          onCloneRepository={(url) => handleCloneRepository(url, 'internal')} 
          onBack={() => navigateTo('dashboard')}
          error={error}
        />
      )}
    </div>
  );
}