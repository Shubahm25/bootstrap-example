import openai
import os
from langchain.document_loaders import TextLoader, DirectoryLoader
from langchain.prompts import PromptTemplate
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains.summarize import load_summarize_chain
from langchain.chat_models import ChatOpenAI
from langchain.llms.bedrock import Bedrock

from utils import bedrock
import json
import os
import sys
import botocore

from dotenv import find_dotenv, load_dotenv

load_dotenv(find_dotenv(), override=True)
bedrock_client = bedrock.get_bedrock_client(
    assumed_role=os.environ.get("BEDROCK_ASSUME_ROLE", None),
    region=os.environ.get("AWS_DEFAULT_REGION", None),
    runtime=False
)


def setup_documents(filepath):
    loader = DirectoryLoader(filepath, glob="**/*.java",
                             show_progress=True, loader_cls=TextLoader)
    docs_raw = loader.load()

    return docs_raw


def generate_documentation(docs, llm, custom_prompt, chain_type):
    custom_prompt = """

    Human:""" + custom_prompt+"""
    <text>
    {text}
    </text>

    Assistant:"""
    COMBINE_PROMPT = PromptTemplate(
        template=custom_prompt, input_variables=["text"])
    MAP_PROMPT = PromptTemplate(
        template=custom_prompt, input_variables=["text"])
    if chain_type == "map_reduce":
        chain = load_summarize_chain(llm, chain_type=chain_type,
                                     map_prompt=MAP_PROMPT,
                                     combine_prompt=COMBINE_PROMPT)
    else:

        prompt = PromptTemplate.from_template(custom_prompt)
        chain = load_summarize_chain(
            llm, chain_type=chain_type, prompt=prompt)

    summary_output = chain({"input_documents": docs}, return_only_outputs=True)[
        "output_text"]

    return summary_output


if __name__ == "__main__":
    docs = setup_documents(
        os.environ["HOME"] + "/Desktop/spring-petclinic-main/src/main")
    print(f'{len(docs)}')
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000,
                                                   chunk_overlap=100)
    for i in range(len(docs)):
        documents = text_splitter.create_documents([docs[i].page_content])
        llm = Bedrock(model_id="anthropic.claude-v2", client=bedrock_client,
                      model_kwargs={'max_tokens_to_sample': 8190, 'stop_sequences': ['Human:']})
        result = generate_documentation(
            documents, llm, "You are a reveerse engineering tool who have to generate reverse engineering documenttation which is understandable by developers your task is to  Generate Reverse engineering documentation of this code in layman terms which is understandable by developers", "stuff")
        path = f'./documentation/document{i+1}.txt'
        data = open(path, 'a')
        data.write(result)
        data.close()
        print(f'document no is :{i+1} and documentation  is :\n{result}\n\n')
