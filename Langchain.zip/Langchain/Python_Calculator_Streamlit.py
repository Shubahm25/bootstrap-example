
class Multiply:
    def multiply(self):
        a = 10
        b = 20
        c = a * b
        return c


class AddTwoNumber:
    def add(self):
        a = 10
        b = 20
        c = a + b
        return c


class Subtract:

    def subtract(self):
        a = 10
        b = 20
        c = a - b
        return c


class Division:
    def divide(self):
        a = 10
        b = 20
        c = b / a
        return c


if __name__ == '__main__':
    add_two_number = AddTwoNumber()
    print(add_two_number.add())

    subtract = Subtract()
    print(subtract.subtract())

    multiply = Multiply()
    print(multiply.multiply())

    division = Division()
    print(division.divide())
