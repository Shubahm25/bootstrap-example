import openai
import os
from langchain.document_loaders import TextLoader, DirectoryLoader
from langchain.prompts import PromptTemplate
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains.summarize import load_summarize_chain
from langchain.chat_models import ChatOpenAI
from langchain.llms.bedrock import Bedrock

from utils import bedrock
import json
import os
import sys
import botocore

from dotenv import find_dotenv, load_dotenv

load_dotenv(find_dotenv(), override=True)
bedrock_client = bedrock.get_bedrock_client(
    assumed_role=os.environ.get("BEDROCK_ASSUME_ROLE", None),
    region=os.environ.get("AWS_DEFAULT_REGION", None),
    runtime=False
)


def setup_documents(filepath, chunk_size, chunk_overlap):
    loader = DirectoryLoader(filepath, glob="**/*.java",
                             show_progress=True, loader_cls=TextLoader)
    docs_raw = loader.load()
    docs_raw_text = [doc.page_content for doc in docs_raw]
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size,
                                                   chunk_overlap=chunk_overlap)
    docs = text_splitter.create_documents(docs_raw_text)

    return docs


def custom_summary(docs, llm, custom_prompt, chain_type):
    custom_prompt = """

    Human:""" + custom_prompt+"""
    <text>
    {text}
    </text>

    Assistant:"""

    COMBINE_PROMPT = PromptTemplate(
        template=custom_prompt, input_variables=["text"])
    MAP_PROMPT = PromptTemplate(
        template=custom_prompt, input_variables=["text"])
    if chain_type == "map_reduce":
        chain = load_summarize_chain(llm, chain_type=chain_type,
                                     map_prompt=MAP_PROMPT,
                                     combine_prompt=COMBINE_PROMPT)
    else:

        prompt = PromptTemplate.from_template(custom_prompt)
        chain = load_summarize_chain(
            llm, chain_type=chain_type, prompt=prompt)

    summary_output = chain({"input_documents": docs}, return_only_outputs=True)[
        "output_text"]

    return summary_output


if __name__ == "__main__":
    docs = setup_documents(
        os.environ["HOME"] + "/Desktop/Langchain/java", 1000, 100)
    print(f'{len(docs)}')
    llm = Bedrock(model_id="anthropic.claude-v2", client=bedrock_client,
                  model_kwargs={'max_tokens_to_sample': 8190, 'stop_sequences': ['Human:']})
    result = custom_summary(
        docs, llm, "You will be acting as an expert software developer in java and python You will translate code from java  to python  which includes class,methods", "stuff")  # stuff will be use as well
    print(f'code generation is  is :\n{result}\n\n')
