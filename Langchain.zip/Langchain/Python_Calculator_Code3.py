class Multiply:
    def multiply(self):
        a = 10
        b = 20
        c = a * b
        return c

# add two numbers


class AddTwoNumbers:
    def add(self):
        a = 10
        b = 20
        c = a + b
        return c

# subtract program


class Subtract:
    def subtract(self):
        a = 10
        b = 20
        c = a - b
        return c

# division program


class Division:
    def divide(self):
        a = 10
        b = 20
        c = b / a
        return c


# main function
if __name__ == "__main__":
    add_two_numbers = AddTwoNumbers()
    print(add_two_numbers.add())

    subtract = Subtract()
    print(subtract.subtract())

    multiply = Multiply()
    print(multiply.multiply())

    division = Division()
    print(division.divide())
