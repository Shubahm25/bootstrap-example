from langchain.document_loaders.generic import GenericLoader
from langchain.document_loaders.parsers import LanguageParser
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
import pinecone
from langchain.vectorstores import Pinecone
from langchain.chains import RetrievalQA
from langchain.chat_models import ChatOpenAI
from langchain.text_splitter import Language
from langchain.chains.summarize import load_summarize_chain
from langchain.prompts import PromptTemplate
from langchain.document_loaders import DirectoryLoader
from langchain.document_loaders import TextLoader

from dotenv import find_dotenv, load_dotenv
import os

load_dotenv(find_dotenv(), override=True)


def load_docs(path):
    loader = DirectoryLoader(path, glob="**/*.java",
                             show_progress=True, loader_cls=TextLoader)

    documents = loader.load()
    return documents


if __name__ == "__main__":
    print(os.environ["HOME"])
    documents = load_docs(
        os.environ["HOME"] + "/Desktop/spring-petclinic-main/src/main")
    # os.environ["HOME"] + "/Desktop/Langchain/java")
    textsplitter = RecursiveCharacterTextSplitter.from_language(
        language=Language.JAVA, chunk_size=1000, chunk_overlap=100
    )
    for i in range(len(documents)):
        docs = textsplitter.create_documents([documents[i].page_content])
        prompt_template = """You will be acting as an expert software developer You have to generate the pseudo code for each class which is understand by developers
        "{text}"
        CONCISE SUMMARY:"""
        prompt = PromptTemplate.from_template(prompt_template)
        llm = ChatOpenAI(temperature=0, model_name="gpt-3.5-turbo-16k")
        chain = load_summarize_chain(llm, chain_type="stuff", prompt=prompt)
        print(chain.run(docs))
