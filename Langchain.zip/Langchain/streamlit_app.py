import openai
import os
from langchain.document_loaders import TextLoader, DirectoryLoader
from langchain.prompts import PromptTemplate
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains.summarize import load_summarize_chain
from langchain.llms.bedrock import Bedrock

from utils import bedrock
import json
import os
import sys
import botocore
import streamlit as st
import time
from dotenv import find_dotenv, load_dotenv
import zipfile
import glob
import os.path
import uuid

load_dotenv(find_dotenv(), override=True)
bedrock_client = bedrock.get_bedrock_client(
    assumed_role=os.environ.get("BEDROCK_ASSUME_ROLE", None),
    region=os.environ.get("AWS_DEFAULT_REGION", None),
    runtime=False
)


def setup_documents(filepath):
    loader = DirectoryLoader(filepath, glob="**/*.cbl",
                             show_progress=True, loader_cls=TextLoader)
    docs_raw = loader.load()

    return docs_raw


def generate_documentation(docs, llm, custom_prompt, chain_type):
    custom_prompt = """

    Human:""" + custom_prompt+"""
    <text>
    {text}
    </text>

    Assistant:"""
    COMBINE_PROMPT = PromptTemplate(
        template=custom_prompt, input_variables=["text"])
    MAP_PROMPT = PromptTemplate(
        template=custom_prompt, input_variables=["text"])
    if chain_type == "map_reduce":
        chain = load_summarize_chain(llm, chain_type=chain_type,
                                     map_prompt=MAP_PROMPT,
                                     combine_prompt=COMBINE_PROMPT)
    else:

        prompt = PromptTemplate.from_template(custom_prompt)
        chain = load_summarize_chain(
            llm, chain_type=chain_type, prompt=prompt)

    summary_output = chain({"input_documents": docs}, return_only_outputs=True)[
        "output_text"]

    return summary_output


def delete_files_in_directory(directory_path):
    try:
        files = os.listdir(directory_path)
        print(len(files))
        for file in files:
            file_path = os.path.join(directory_path, file)
            if os.path.isfile(file_path):
                os.remove(file_path)
        print("All files deleted successfully.")
    except OSError:
        print("Error occurred while deleting files.")


def main():
    st.set_page_config("centered")
    st.title("Reverse Documentation Tool")
    path = st.text_input("Enter the path")
    if path != "":
        with st.spinner("In Progress"):
            docs = setup_documents(path)
            st.success("File Loaded Successfully")
    user_prompt = st.text_input("Enter the prompt")
    unique_filename = str(uuid.uuid4())+".zip"
    if st.button("Generate_Documentation"):
        with st.spinner("In Progress"):
            delete_files_in_directory('./documentation/')
            text_splitter = RecursiveCharacterTextSplitter(chunk_size=2000,
                                                           chunk_overlap=200)
            for i in range(len(docs)):
                documents = text_splitter.create_documents(
                    [docs[i].page_content])

                llm = Bedrock(model_id="anthropic.claude-v2", client=bedrock_client,
                              model_kwargs={'max_tokens_to_sample': 8190, 'stop_sequences': ['Human:']})
                result = generate_documentation(
                    documents, llm, user_prompt, "stuff")
                path = f'./documentation/document{i+1}.txt'
                data = open(path, 'a')
                data.write(result)
                data.close()
                # print(
                #     f'document no is :{i+1} and documentation  is :\n{result}\n\n')
            with zipfile.ZipFile(unique_filename, 'w') as f:
                for file in glob.glob('documentation/*'):
                    f.write(file)
            st.success(
                "documentation generated successfully Click here to download")
    if os.path.isfile(unique_filename):
        with open(unique_filename, 'rb') as f:
            st.download_button('Download Documentation', f,
                               file_name=unique_filename)


if __name__ == "__main__":
    main()
