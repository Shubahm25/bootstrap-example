from langchain.document_loaders.generic import GenericLoader
from langchain.document_loaders.parsers import LanguageParser
from langchain.text_splitter import Language
from langchain.text_splitter import RecursiveCharacterTextSplitter


def load_docs(path):
    loader = GenericLoader.from_filesystem(
        path,
        glob="**/*",
        suffixes=[".java"],
        parser=LanguageParser(language=Language.JAVA, parser_threshold=200)
    )
    documents = loader.load()
    return documents


def split_docs():
    documents = load_docs("java/")
    splitter = RecursiveCharacterTextSplitter.from_language(
        Language.JAVA, chunk_size=100, chunk_overlap=20)
    texts = splitter.split_documents(documents)
    return texts

