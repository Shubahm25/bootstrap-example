Function BreakString(ByVal str1, ByVal
maxLength, ByRef.blnDone As
Boolean)

Dim curChar As String
Dim i As Integer

Dim bInGotNonWhiteSpace As Boolean 
bInGotNonWhiteSpace = False
blnDone = False

If Len(str1) <= maxLength Then
	BreakString = str1 .
	Exit Function
End If

For i = Len(Left(str1, maxlength))  To 1 Step -1
	curChar = Mid(str1, i, 1)
	If curChar = “” Then
		If Not bInGotNonWhiteSpace Then Exit For ’
		BreakString = Mid(str1, i)
		Exit Function
	Else 
		bInGotNonWhiteSpace = True
	End If :
Next
blnDone = True
BreakString = Left(str1,maxLength)
‘End Function