from langchain.document_loaders.generic import GenericLoader
from langchain.document_loaders.parsers import LanguageParser
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
import pinecone
from langchain.vectorstores import Pinecone
from langchain.chains import RetrievalQA
from langchain.chat_models import ChatOpenAI
from langchain.text_splitter import Language


from dotenv import find_dotenv, load_dotenv
import os

load_dotenv(find_dotenv(), override=True)


def load_docs(path):
    loader = GenericLoader.from_filesystem(
        path=path,
        glob="**/*",
        parser=LanguageParser(parser_threshold=200))

    documents = loader.load()
    return documents


def split_docs():
    documents = load_docs("java/")
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=2000, chunk_overlap=200)
    documents = splitter.split_documents(documents)
    return documents


def insert_of_fetch_embeddings():
    embeddings = OpenAIEmbeddings(tiktoken_model_name="ada")
    pinecone.init(api_key=os.environ.get("PINECONE_API_KEY"),
                  environment=os.environ.get("PINECONE_ENV"))
    index_name = "demo"

    if index_name in pinecone.list_indexes():
        print(f'Index {index_name} already exists. Load Embeddings...', end='')
        vector_store = Pinecone.from_existing_index(index_name, embeddings)
        print('Done!')
    else:
        pinecone.create_index(index_name, dimension=1536, metric='cosine')
        documents = split_docs()
        vector_store = Pinecone.from_documents(
            documents, embeddings, index_name=index_name)
        print('Done')
    return vector_store


def get_answer(query):
    vector_store = insert_of_fetch_embeddings()
    retriever = vector_store.as_retriever(
        search_type="similarity", search_kwargs={'k': 2})
    chat = ChatOpenAI(verbose=True, temperature=0)
    retrieval_chain = RetrievalQA.from_chain_type(
        llm=chat,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents=True,
    )
    response = retrieval_chain({"query": query})
    return response


def process_llm_response(response):
    print(f'llm response: {response["result"]}')
    print("\nsources:")
    for source in response["source_documents"]:
        print(source.metadata['source'])


if __name__ == "__main__":
    # vector_store = insert_of_fetch_embeddings()
    # print(vector_store.similarity_search('summarize this file??'))
    response = (get_answer("summarize the java program"))
    # # print(response)
    process_llm_response(response)
    # # print(response) program??"))
    # # print(response)
    # process_llm_response(response)
