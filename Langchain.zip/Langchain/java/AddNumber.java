//add two number java program
import java.util.Scanner;
public class AddTwoNumber { 
      public int add() {
        int a = 10;
        int b = 20;
        int c = a + b;
       return c;
    }
}