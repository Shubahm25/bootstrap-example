// write java subract program in java
public class Division {
    public int divide() {
        int a = 10;
        int b = 20;
        int c = b / a;
       return c;
    }
}