// write java subract program in java
public class Subtract {
    public int subtract() {
        int a = 10;
        int b = 20;
        int c = a - b;
       return c;
    }
}