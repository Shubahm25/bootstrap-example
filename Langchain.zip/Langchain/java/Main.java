

public class Main{
public static void main(String[] args){
AddTwoNumber addTwoNumber = new AddTwoNumber();
System.out.println(addTwoNumber.add());
Subtract subract = new Subtract();
System.out.println(subract.subtract());
Multiply multiply = new Multiply();
System.out.println(multiply.multiply());
Division division = new Division();
System.out.println(division.divide());
}
}

