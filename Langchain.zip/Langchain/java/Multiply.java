// write java subract program in java
public class Multiply {
    public int multiply() {
        int a = 10;
        int b = 20;
        int c = a * b;
       return c;
    }
}